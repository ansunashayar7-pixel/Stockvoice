# StockVoice authentication & data security

- Passwords are stored as salted scrypt hashes, never plaintext.
- Auth uses short-lived-ish bearer tokens (30-day expiry in this MVP); production should use HTTPS, refresh-token rotation and rate limiting.
- User records are stored server-side; the Android client should only keep the auth token in encrypted local storage.
- Never put market-data provider secrets or JWT_SECRET in the APK.
- Premium entitlement is server-owned. A production release must set premium only after verified Google Play Billing purchase/subscription state (and preferably RTDN/backend verification).
- Do not log passwords, tokens, payment information, or personal data.
- Before public launch, replace the JSON datastore with a managed database, add backups, encryption at rest, rate limiting, email verification, account deletion, privacy-policy/consent flows, and monitoring.
