# Live provider integration

Production should use an exchange-authorised/licensed NSE/BSE feed. TrueData documents real-time NSE/BSE/MCX market data over REST/WebSocket, including LTP and price-change fields.

Android expects:
{"quotes":[{"symbol":"RELIANCE","name":"Reliance Industries","price":1420.30,"changePct":0.82}]}

Never put vendor credentials in the APK. Authenticate from the backend and normalize the provider response to this contract.
