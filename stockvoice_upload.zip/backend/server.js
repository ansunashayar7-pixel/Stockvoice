import express from 'express';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

const app = express();
app.use(express.json({ limit: '256kb' }));
const PORT = Number(process.env.PORT || 8080);
const PROVIDER = process.env.MARKET_DATA_PROVIDER || 'demo';
const UPSTREAM_URL = process.env.MARKET_DATA_URL || '';
const UPSTREAM_TOKEN = process.env.MARKET_DATA_TOKEN || '';
const CACHE_MS = Number(process.env.QUOTE_CACHE_MS || 20000);
const JWT_SECRET = process.env.JWT_SECRET || 'CHANGE_ME_IN_PRODUCTION';
const DATA_FILE = process.env.USER_DATA_FILE || path.join(process.cwd(), 'data', 'users.json');

if (JWT_SECRET === 'CHANGE_ME_IN_PRODUCTION') console.warn('WARNING: Set a strong JWT_SECRET in production.');
fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
let users = {};
try { users = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); } catch { users = {}; }
function persistUsers() {
  const tmp = `${DATA_FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(users, null, 2), { mode: 0o600 });
  fs.renameSync(tmp, DATA_FILE);
}
function id() { return crypto.randomUUID(); }
function normalizeEmail(v) { return String(v || '').trim().toLowerCase(); }
function validEmail(v) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v); }
function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  return new Promise((resolve, reject) => crypto.scrypt(password, salt, 64, (e, dk) => e ? reject(e) : resolve(`${salt}:${dk.toString('hex')}`)));
}
async function verifyPassword(password, stored) {
  const [salt, hex] = String(stored).split(':');
  if (!salt || !hex) return false;
  const actual = await hashPassword(password, salt);
  return crypto.timingSafeEqual(Buffer.from(actual.split(':')[1], 'hex'), Buffer.from(hex, 'hex'));
}
function signToken(payload) {
  const b64 = (x) => Buffer.from(JSON.stringify(x)).toString('base64url');
  const head = b64({ alg: 'HS256', typ: 'JWT' });
  const body = b64({ ...payload, iat: Math.floor(Date.now()/1000), exp: Math.floor(Date.now()/1000) + 60*60*24*30 });
  const sig = crypto.createHmac('sha256', JWT_SECRET).update(`${head}.${body}`).digest('base64url');
  return `${head}.${body}.${sig}`;
}
function readToken(token) {
  const [h, p, s] = String(token || '').split('.');
  if (!h || !p || !s) return null;
  const expected = crypto.createHmac('sha256', JWT_SECRET).update(`${h}.${p}`).digest('base64url');
  const got = Buffer.from(s); const want = Buffer.from(expected);
  if (got.length !== want.length || !crypto.timingSafeEqual(got, want)) return null;
  const payload = JSON.parse(Buffer.from(p, 'base64url').toString());
  if (!payload.exp || payload.exp < Math.floor(Date.now()/1000)) return null;
  return payload;
}
function auth(req, res, next) {
  const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  const p = readToken(token);
  if (!p || !users[p.sub]) return res.status(401).json({ error: 'unauthorized' });
  req.user = users[p.sub];
  next();
}
function publicUser(u) { return { id: u.id, email: u.email, premium: !!u.premium, premiumSource: u.premiumSource || null }; }

app.post('/auth/register', async (req, res) => {
  const email = normalizeEmail(req.body?.email), password = String(req.body?.password || '');
  if (!validEmail(email)) return res.status(400).json({ error: 'valid email required' });
  if (password.length < 8) return res.status(400).json({ error: 'password must be at least 8 characters' });
  if (Object.values(users).some(u => u.email === email)) return res.status(409).json({ error: 'account already exists' });
  const user = { id: id(), email, passwordHash: await hashPassword(password), premium: false, premiumSource: null, createdAt: new Date().toISOString(), watchlist: [], alerts: [] };
  users[user.id] = user; persistUsers();
  res.status(201).json({ user: publicUser(user), token: signToken({ sub: user.id }) });
});

app.post('/auth/login', async (req, res) => {
  const email = normalizeEmail(req.body?.email), password = String(req.body?.password || '');
  const user = Object.values(users).find(u => u.email === email);
  if (!user || !(await verifyPassword(password, user.passwordHash))) return res.status(401).json({ error: 'invalid email or password' });
  res.json({ user: publicUser(user), token: signToken({ sub: user.id }) });
});
app.get('/auth/me', auth, (req, res) => res.json({ user: publicUser(req.user) }));

// Premium is intentionally server-owned. In production this flag is updated only after
// verified Google Play subscription purchase/RTDN processing; clients never set it directly.
app.get('/me/entitlements', auth, (req, res) => res.json({ premium: !!req.user.premium, source: req.user.premiumSource || null }));
app.get('/me/sync', auth, (req, res) => {
  res.json({ watchlist: req.user.watchlist || [], alerts: req.user.alerts || [], updatedAt: req.user.updatedAt || null });
});

app.put('/me/sync', auth, (req, res) => {
  const watchlist = Array.isArray(req.body?.watchlist) ? cleanSymbols(req.body.watchlist) : null;
  const alerts = Array.isArray(req.body?.alerts) ? req.body.alerts.slice(0, 100).filter(a =>
    a && typeof a === 'object' && /^[A-Z0-9._-]{1,30}$/.test(String(a.symbol || '').toUpperCase()) &&
    ['ABOVE','BELOW','PCT_UP','PCT_DOWN'].includes(a.type) && Number.isFinite(Number(a.value))
  ).map(a => ({ id: String(a.id || crypto.randomUUID()), symbol: String(a.symbol).toUpperCase(), name: String(a.name || a.symbol), type: a.type, value: Number(a.value), enabled: a.enabled !== false })) : null;
  if (!watchlist && !alerts) return res.status(400).json({ error: 'watchlist or alerts required' });
  if (watchlist) req.user.watchlist = watchlist;
  if (alerts) req.user.alerts = alerts;
  req.user.updatedAt = new Date().toISOString();
  persistUsers();
  res.json({ watchlist: req.user.watchlist, alerts: req.user.alerts, updatedAt: req.user.updatedAt });
});

const catalog = { RELIANCE: ['Reliance Industries', 1420.30], TATAMOTORS: ['Tata Motors', 735.60], INFY: ['Infosys', 1568.75], HDFCBANK: ['HDFC Bank', 1724.20], TCS: ['TCS', 3425.15] };
const cache = new Map();
function cleanSymbols(input) { return [...new Set(input.map(s => String(s).trim().toUpperCase()).filter(s => /^[A-Z0-9._-]{1,30}$/.test(s)))].slice(0, 50); }
function normalizeProviderQuote(q) { return { symbol: String(q.symbol ?? q.ticker ?? '').toUpperCase(), name: q.name ?? q.companyName ?? q.symbol ?? q.ticker, price: Number(q.price ?? q.last ?? q.lastPrice ?? q.ltp), changePct: Number(q.changePct ?? q.change_percent ?? q.pChange ?? q.percentChange ?? 0), demo: false, asOf: q.asOf ?? q.timestamp ?? new Date().toISOString() }; }
async function getQuotes(symbols) {
  const clean = cleanSymbols(symbols); if (!clean.length) throw new Error('valid symbols required');
  const key = clean.join(','); const cached = cache.get(key); if (cached && Date.now()-cached.at<CACHE_MS) return cached.quotes;
  if (PROVIDER === 'upstream') {
    if (!UPSTREAM_URL) throw new Error('MARKET_DATA_URL is not configured');
    const url = UPSTREAM_URL.replace('{symbols}', encodeURIComponent(key));
    const rr = await fetch(url, { headers: UPSTREAM_TOKEN ? { Authorization: `Bearer ${UPSTREAM_TOKEN}` } : {} });
    if (!rr.ok) throw new Error(`market provider error ${rr.status}`);
    const payload = await rr.json(); const raw = Array.isArray(payload) ? payload : (payload.quotes || payload.data || []);
    const quotes = raw.map(normalizeProviderQuote).filter(q => q.symbol && Number.isFinite(q.price)); cache.set(key,{at:Date.now(),quotes}); return quotes;
  }
  const now = Date.now()/60000; const quotes = clean.map((symbol,i)=>{ const [name,base]=catalog[symbol]||[symbol,100]; const changePct=Number(((Math.sin(now/8+i)*0.7)+(Math.sin(now/2+i)*0.15)).toFixed(2)); return {symbol,name,price:Number((base*(1+changePct/100)).toFixed(2)),changePct,demo:true,asOf:new Date().toISOString()}; });
  cache.set(key,{at:Date.now(),quotes}); return quotes;
}
app.get('/health', (_req,res)=>res.json({ok:true,provider:PROVIDER,mode:PROVIDER==='demo'?'SIMULATED':'LIVE_PROVIDER'}));
app.get('/symbols', (_req,res)=>res.json({symbols:Object.entries(catalog).map(([symbol,[name]])=>({symbol,name}))}));
app.get('/quotes', async (req,res)=>{try{const symbols=String(req.query.symbols||'').split(',');res.json({quotes:await getQuotes(symbols),demo:PROVIDER==='demo',provider:PROVIDER});}catch(e){res.status(502).json({error:e.message||'quote service failed'});}});
app.post('/alerts/evaluate', auth, async (req,res)=>{const alerts=Array.isArray(req.body?.alerts)?req.body.alerts.slice(0,100):[];if(!alerts.length)return res.json({triggered:[],quotes:[]});try{const quotes=await getQuotes(alerts.map(a=>a.symbol));const bySymbol=new Map(quotes.map(q=>[q.symbol,q]));const triggered=alerts.filter(a=>{const q=bySymbol.get(String(a.symbol).toUpperCase());if(!q||a.enabled===false)return false;const v=Number(a.value);if(!Number.isFinite(v))return false;if(a.type==='ABOVE')return q.price>=v;if(a.type==='BELOW')return q.price<=v;if(a.type==='PCT_UP')return q.changePct>=v;if(a.type==='PCT_DOWN')return q.changePct<=-Math.abs(v);return false;}).map(a=>({...a,quote:bySymbol.get(String(a.symbol).toUpperCase())}));res.json({triggered,quotes,demo:PROVIDER==='demo',provider:PROVIDER});}catch(e){res.status(502).json({error:e.message||'alert evaluation failed'});}});

app.listen(PORT,()=>console.log(`StockVoice backend :${PORT} provider=${PROVIDER}`));
