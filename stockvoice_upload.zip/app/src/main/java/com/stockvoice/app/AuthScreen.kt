package com.stockvoice.app

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun AuthGate(onAuthenticated: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var register by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    MaterialTheme(colorScheme = darkColorScheme(background=Color(0xFF06141D), surface=Color(0xFF102431), primary=Color(0xFF20E0B0), onPrimary=Color.Black)) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement=Arrangement.Center) {
            Text("StockVoice", style=MaterialTheme.typography.headlineLarge, color=Color.White)
            Text(if (register) "Create your secure account" else "Login to continue", color=Color.LightGray, modifier=Modifier.padding(top=6.dp,bottom=22.dp))
            OutlinedTextField(email,{email=it},label={Text("Email")},singleLine=true,modifier=Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(password,{password=it},label={Text("Password")},singleLine=true,visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())
            error?.let { Text(it,color=Color(0xFFFF5570),modifier=Modifier.padding(top=8.dp)) }
            Spacer(Modifier.height(14.dp))
            Button(enabled=!busy,onClick={
                error=null; busy=true
                scope.launch {
                    val ok=runCatching { withContext(Dispatchers.IO) { if(register) AuthClient.register(context,email,password) else AuthClient.login(context,email,password) } }.onFailure { error=it.message ?: "Could not connect" }.isSuccess
                    busy=false; if(ok) { runCatching { withContext(Dispatchers.IO) { CloudSyncClient.pull(context) } }; onAuthenticated() }
                }
            },modifier=Modifier.fillMaxWidth()) { Text(if(busy) "Please wait…" else if(register) "Create Account" else "Login") }
            TextButton(onClick={register=!register;error=null},modifier=Modifier.fillMaxWidth()) { Text(if(register) "Already have an account? Login" else "New here? Create an account") }
            Text("Your password is hashed on the server. The session token is encrypted with Android Keystore on this device.",color=Color.Gray,style=MaterialTheme.typography.bodySmall,modifier=Modifier.padding(top=18.dp))
        }
    }
}
