package com.stockvoice.app

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.*

/** Google Play Billing client. Product ID is configured in Play Console before production. */
class BillingManager(private val context: Context) : PurchasesUpdatedListener {
    companion object { const val PREMIUM_PRODUCT_ID = "stockvoice_premium_monthly" }
    private val billingClient = BillingClient.newBuilder(context)
        .setListener(this).enablePendingPurchases().build()

    fun connect(onReady: (Boolean) -> Unit) {
        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) { onReady(result.responseCode == BillingClient.BillingResponseCode.OK) }
            override fun onBillingServiceDisconnected() { }
        })
    }

    fun launchPremium(activity: Activity, onUnavailable: () -> Unit = {}) {
        if (!billingClient.isReady) { onUnavailable(); return }
        val params = QueryProductDetailsParams.newBuilder().setProductList(listOf(
            QueryProductDetailsParams.Product.newBuilder().setProductId(PREMIUM_PRODUCT_ID).setProductType(BillingClient.ProductType.SUBS).build()
        )).build()
        billingClient.queryProductDetailsAsync(params) { result, details ->
            val product = details.firstOrNull() ?: run { onUnavailable(); return@queryProductDetailsAsync }
            val offer = product.subscriptionOfferDetails?.firstOrNull() ?: run { onUnavailable(); return@queryProductDetailsAsync }
            val flow = BillingFlowParams.newBuilder().setProductDetailsParamsList(listOf(
                BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(product).setOfferToken(offer.offerToken).build()
            )).build()
            billingClient.launchBillingFlow(activity, flow)
        }
    }

    override fun onPurchasesUpdated(result: BillingResult, purchases: MutableList<Purchase>?) {
        // IMPORTANT: production entitlement is granted only after backend verification of purchaseToken.
        // Do not set premium locally from this callback.
    }

    fun close() { billingClient.endConnection() }
}
