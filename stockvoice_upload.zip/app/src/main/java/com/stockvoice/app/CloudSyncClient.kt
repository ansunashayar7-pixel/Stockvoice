package com.stockvoice.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object CloudSyncClient {
    private fun baseUrl(context: Context) = context.getSharedPreferences("stockvoice_prefs", Context.MODE_PRIVATE)
        .getString("backend_url", "http://10.0.2.2:8080")!!.trimEnd('/')

    private fun request(context: Context, path: String, method: String, body: JSONObject? = null): JSONObject {
        val c = (URL(baseUrl(context) + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method; connectTimeout = 7000; readTimeout = 10000
            setRequestProperty("Accept", "application/json")
            SecureTokenStore.token(context)?.let { setRequestProperty("Authorization", "Bearer $it") }
            if (body != null) { doOutput = true; setRequestProperty("Content-Type", "application/json") }
        }
        return try {
            body?.let { c.outputStream.use { out -> out.write(it.toString().toByteArray()) } }
            val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
            if (c.responseCode !in 200..299) throw IllegalStateException(JSONObject(text).optString("error", "Sync failed"))
            JSONObject(text)
        } finally { c.disconnect() }
    }

    fun pull(context: Context) {
        val o = request(context, "/me/sync", "GET")
        val w = o.optJSONArray("watchlist") ?: JSONArray()
        val watch = buildList { for (i in 0 until w.length()) add(w.getString(i)) }
        if (watch.isNotEmpty()) WatchlistRepository.save(context, watch)
        val a = o.optJSONArray("alerts") ?: JSONArray()
        val alerts = buildList {
            for (i in 0 until a.length()) { val x=a.getJSONObject(i); add(PriceAlert(x.optString("id"), x.optString("symbol"), x.optString("name"), x.optString("type"), x.optDouble("value"), x.optBoolean("enabled", true))) }
        }
        AlertRepository.save(context, alerts)
    }

    fun push(context: Context) {
        val w = JSONArray().apply { WatchlistRepository.load(context).forEach { put(it) } }
        val a = JSONArray().apply { AlertRepository.load(context).forEach { x -> put(JSONObject().apply { put("id",x.id); put("symbol",x.symbol); put("name",x.name); put("type",x.type); put("value",x.value); put("enabled",x.enabled) }) } }
        request(context, "/me/sync", "PUT", JSONObject().put("watchlist", w).put("alerts", a))
    }
}
