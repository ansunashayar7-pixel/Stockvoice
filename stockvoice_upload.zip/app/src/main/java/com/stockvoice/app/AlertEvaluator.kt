package com.stockvoice.app

import android.content.Context
import org.json.JSONObject
import kotlin.math.abs

object AlertEvaluator {
    data class Result(val message: String?, val triggeredIds: Set<String>)
    private const val PREFS = "stockvoice_alert_state"

    fun evaluate(context: Context, quotes: List<MarketDataClient.Quote>): Result {
        if (!MarketHours.isOpen()) return Result(null, emptySet())
        val alerts = AlertRepository.load(context).filter { it.enabled }
        val bySymbol = quotes.associateBy { it.symbol.uppercase() }
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val triggered = mutableSetOf<String>()
        val messages = mutableListOf<String>()
        val editor = prefs.edit()

        alerts.forEach { a ->
            val q = bySymbol[a.symbol.uppercase()] ?: return@forEach
            val hit = when (a.type) {
                "ABOVE" -> q.price >= a.value
                "BELOW" -> q.price <= a.value
                "PCT_UP" -> q.changePct >= a.value
                "PCT_DOWN" -> q.changePct <= -abs(a.value)
                else -> false
            }
            val stateKey = "${a.id}:hit"
            val wasHit = prefs.getBoolean(stateKey, false)
            // Fire only on a crossing. This prevents the same alert from speaking every 5 minutes.
            if (hit && !wasHit) {
                triggered += a.id
                messages += when (a.type) {
                    "ABOVE" -> "${a.name} crossed above rupees ${format(a.value)}. Current price is ${format(q.price)}."
                    "BELOW" -> "${a.name} crossed below rupees ${format(a.value)}. Current price is ${format(q.price)}."
                    "PCT_UP" -> "${a.name} moved up ${format(a.value)} percent or more. Current move is ${format(q.changePct)} percent."
                    else -> "${a.name} moved down ${format(a.value)} percent or more. Current move is ${format(q.changePct)} percent."
                }
            }
            editor.putBoolean(stateKey, hit)
        }
        editor.apply()
        return Result(messages.take(5).joinToString(" ").ifBlank { null }, triggered)
    }

    fun clearState(context: Context, alertId: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove("$alertId:hit").apply()
    }

    private fun format(v: Double) = String.format(java.util.Locale.US, "%.2f", v)
}
