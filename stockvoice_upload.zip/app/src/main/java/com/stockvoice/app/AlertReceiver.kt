package com.stockvoice.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlertReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action
        if (action == Intent.ACTION_BOOT_COMPLETED || action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            val prefs = context.getSharedPreferences("stockvoice_prefs", Context.MODE_PRIVATE)
            if (prefs.getBoolean("session", false)) AlertScheduler.schedule(context, prefs.getLong("alarm_minutes", 5))
            return
        }
        val prefs = context.getSharedPreferences("stockvoice_prefs", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("session", false)) return
        if (MarketHours.isOpen()) VoiceAlertService.start(context)
        AlertScheduler.rescheduleFromReceiver(context)
    }

    companion object {
        fun symbolsForSession(context: Context): List<String> =
            WatchlistRepository.load(context).ifEmpty { listOf("RELIANCE") }
    }
}
