package com.stockvoice.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class PriceAlert(
    val id: String = UUID.randomUUID().toString(),
    val symbol: String,
    val name: String,
    val type: String,
    val value: Double,
    val enabled: Boolean = true
)

object AlertRepository {
    private const val PREFS = "stockvoice_prefs"
    private const val KEY_ALERTS = "price_alerts"

    fun load(context: Context): List<PriceAlert> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_ALERTS, "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    add(PriceAlert(
                        id = o.optString("id"), symbol = o.getString("symbol"), name = o.getString("name"),
                        type = o.getString("type"), value = o.getDouble("value"), enabled = o.optBoolean("enabled", true)
                    ))
                }
            }
        }.getOrDefault(emptyList())
    }

    fun save(context: Context, alerts: List<PriceAlert>) {
        val arr = JSONArray()
        alerts.forEach { a ->
            arr.put(JSONObject().apply {
                put("id", a.id); put("symbol", a.symbol); put("name", a.name)
                put("type", a.type); put("value", a.value); put("enabled", a.enabled)
            })
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_ALERTS, arr.toString()).apply()
    }
}
