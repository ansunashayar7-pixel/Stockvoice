package com.stockvoice.app

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object AuthClient {
    data class User(val id: String, val email: String, val premium: Boolean, val premiumSource: String?)
    data class Result(val user: User, val token: String)

    private fun baseUrl(context: Context) = context.getSharedPreferences("stockvoice_prefs", Context.MODE_PRIVATE)
        .getString("backend_url", "http://10.0.2.2:8080")!!.trimEnd('/')

    private fun request(context: Context, path: String, method: String, body: JSONObject? = null, auth: Boolean = false): JSONObject {
        val c = (URL(baseUrl(context) + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method; connectTimeout = 7000; readTimeout = 10000
            setRequestProperty("Accept", "application/json")
            if (body != null) { doOutput = true; setRequestProperty("Content-Type", "application/json") }
            if (auth) SecureTokenStore.token(context)?.let { setRequestProperty("Authorization", "Bearer $it") }
        }
        return try {
            body?.let { c.outputStream.use { out -> out.write(it.toString().toByteArray()) } }
            val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
            if (c.responseCode !in 200..299) throw IllegalStateException(JSONObject(text).optString("error", "Request failed"))
            JSONObject(text)
        } finally { c.disconnect() }
    }

    private fun parseUser(o: JSONObject): User { val u=o.getJSONObject("user"); return User(u.getString("id"),u.getString("email"),u.optBoolean("premium"),u.optString("premiumSource").ifBlank{null}) }
    fun register(context: Context, email: String, password: String): Result { val r=request(context,"/auth/register","POST",JSONObject().put("email",email).put("password",password)); val u=parseUser(r); val t=r.getString("token"); SecureTokenStore.saveToken(context,t); return Result(u,t) }
    fun login(context: Context, email: String, password: String): Result { val r=request(context,"/auth/login","POST",JSONObject().put("email",email).put("password",password)); val u=parseUser(r); val t=r.getString("token"); SecureTokenStore.saveToken(context,t); return Result(u,t) }
    fun me(context: Context): User { return parseUser(request(context,"/auth/me","GET",auth=true)) }
    fun entitlements(context: Context): Boolean = request(context,"/me/entitlements","GET",auth=true).optBoolean("premium",false)
}
