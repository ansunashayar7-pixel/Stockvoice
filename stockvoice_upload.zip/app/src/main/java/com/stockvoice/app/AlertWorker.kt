package com.stockvoice.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.work.Worker
import androidx.work.WorkerParameters

class AlertWorker(appContext: Context, params: WorkerParameters) : Worker(appContext, params) {
    override fun doWork(): Result {
        val symbols = AlertReceiver.symbolsForSession(applicationContext)
        val quotes = runCatching { MarketDataClient.fetchQuotes(applicationContext, symbols) }.getOrDefault(emptyList())
        val evaluation = AlertEvaluator.evaluate(applicationContext, quotes)
        val body = evaluation.message ?: if (quotes.isEmpty()) "Unable to fetch market data right now." else quotes.joinToString(" • ") { "${it.symbol} ₹${String.format("%.2f", it.price)} (${String.format("%.2f", it.changePct)}%)" }
        val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("stockvoice_alerts", "StockVoice alerts", NotificationManager.IMPORTANCE_HIGH))
        nm.notify(1001, NotificationCompat.Builder(applicationContext, "stockvoice_alerts")
            .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(if (evaluation.message != null) "StockVoice price alert" else "StockVoice market update")
            .setContentText(body).setStyle(NotificationCompat.BigTextStyle().bigText(body)).setAutoCancel(true).build())
        return if (quotes.isEmpty()) Result.retry() else Result.success()
    }
}
