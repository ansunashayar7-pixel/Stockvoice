package com.stockvoice.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.work.*
import java.util.concurrent.TimeUnit

/**
 * Schedules user-requested voice updates. Exact alarms are preferred for all
 * supported intervals because the feature is explicitly time-based and must
 * trigger the voice service. If exact-alarm access is unavailable, 15/30/60m
 * fall back to WorkManager (which may run later).
 */
object AlertScheduler {
    private const val REQUEST_CODE = 4205
    private const val ACTION_ALERT = "com.stockvoice.app.ACTION_VOICE_ALERT"

    fun schedule(context: Context, minutes: Long = 5) {
        val safe = minutes.coerceIn(5, 60)
        val prefs = context.getSharedPreferences("stockvoice_prefs", Context.MODE_PRIVATE)
        prefs.edit().putBoolean("session", true).putLong("alarm_minutes", safe).apply()

        WorkManager.getInstance(context).cancelUniqueWork("stockvoice_alerts")
        cancelExact(context)

        if (canUseExactAlarms(context)) {
            scheduleExact(context, safe)
        } else if (safe >= 15) {
            scheduleWorkFallback(context, safe)
        }
        // For 5/10 minutes, Android requires exact-alarm access. The UI already
        // sends the user to the system permission page when needed.
    }

    private fun canUseExactAlarms(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            context.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()

    private fun scheduleExact(context: Context, minutes: Long) {
        val triggerAt = System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(minutes)
        val am = context.getSystemService(AlarmManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent(context))
        } else {
            am.setExact(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent(context))
        }
    }

    private fun scheduleWorkFallback(context: Context, minutes: Long) {
        val request = PeriodicWorkRequestBuilder<AlertWorker>(minutes, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "stockvoice_alerts", ExistingPeriodicWorkPolicy.UPDATE, request
        )
    }

    fun rescheduleFromReceiver(context: Context) {
        val prefs = context.getSharedPreferences("stockvoice_prefs", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("session", false)) return
        schedule(context, prefs.getLong("alarm_minutes", 5))
    }

    fun cancel(context: Context) {
        context.getSharedPreferences("stockvoice_prefs", Context.MODE_PRIVATE)
            .edit().putBoolean("session", false).apply()
        cancelExact(context)
        WorkManager.getInstance(context).cancelUniqueWork("stockvoice_alerts")
    }

    private fun cancelExact(context: Context) =
        context.getSystemService(AlarmManager::class.java).cancel(pendingIntent(context))

    private fun pendingIntent(context: Context): PendingIntent = PendingIntent.getBroadcast(
        context,
        REQUEST_CODE,
        Intent(context, AlertReceiver::class.java).setAction(ACTION_ALERT),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}
