package com.stockvoice.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import java.util.Locale
import java.util.concurrent.Executors

class VoiceAlertService : Service() {
    private var tts: TextToSpeech? = null
    private val executor = Executors.newSingleThreadExecutor()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        startForeground(NOTIFICATION_ID, NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("StockVoice alert")
            .setContentText("Checking your watchlist…").setOngoing(false).build())

        executor.execute {
            val symbols = AlertReceiver.symbolsForSession(this)
            val quotes = runCatching { MarketDataClient.fetchQuotes(this, symbols) }.getOrDefault(emptyList())
            val prefs = getSharedPreferences("stockvoice_prefs", Context.MODE_PRIVATE)
            val language = prefs.getString("language", "English") ?: "English"
            val announceChange = prefs.getBoolean("announce_change", true)
            val evaluation = AlertEvaluator.evaluate(this, quotes)
            val text = evaluation.message ?: if (quotes.isEmpty()) {
                "StockVoice could not fetch the latest market prices. Please check your internet connection."
            } else buildString {
                append("StockVoice update. ")
                quotes.take(10).forEachIndexed { index, q ->
                    if (index > 0) append(". ")
                    append(q.name).append(" current price is ").append(String.format(Locale.US, "%.2f", q.price)).append(" rupees")
                    if (announceChange) append(". Daily movement ").append(String.format(Locale.US, "%.2f", q.changePct)).append(" percent")
                }
            }
            android.os.Handler(mainLooper).post {
                tts = TextToSpeech(this) { status ->
                    if (status == TextToSpeech.SUCCESS) {
                        val wanted = if (language == "Hindi") Locale("hi", "IN") else Locale("en", "IN")
                        if (tts?.isLanguageAvailable(wanted) ?: -1 >= TextToSpeech.LANG_AVAILABLE) tts?.language = wanted else tts?.language = Locale("en", "IN")
                        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "stockvoice-alert")
                    }
                    stopSelf(startId)
                }
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() { executor.shutdownNow(); tts?.stop(); tts?.shutdown(); tts = null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "StockVoice Alerts", NotificationManager.IMPORTANCE_LOW)
        )
    }
    companion object {
        private const val CHANNEL = "stockvoice_alerts"; private const val NOTIFICATION_ID = 7001
        fun start(context: Context) {
            val intent = Intent(context, VoiceAlertService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent) else context.startService(intent)
        }
    }
}
