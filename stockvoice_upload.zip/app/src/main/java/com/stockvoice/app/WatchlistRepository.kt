package com.stockvoice.app

import android.content.Context
import org.json.JSONArray

object WatchlistRepository {
    private const val PREFS = "stockvoice_prefs"
    private const val KEY = "watchlist_symbols"
    private val defaults = listOf("RELIANCE", "TATAMOTORS", "INFY", "HDFCBANK", "TCS")

    fun load(context: Context): List<String> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
            ?: return defaults
        return runCatching {
            val a = JSONArray(raw)
            buildList { for (i in 0 until a.length()) add(a.getString(i)) }
        }.getOrDefault(defaults)
    }

    fun save(context: Context, symbols: List<String>) {
        val clean = symbols.map { it.trim().uppercase() }.filter { it.isNotBlank() }.distinct().take(50)
        val a = JSONArray().apply { clean.forEach { put(it) } }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).apply()
    }

    fun toggle(context: Context, symbol: String): List<String> {
        val current = load(context).toMutableList()
        val normalized = symbol.uppercase()
        if (normalized in current) current.remove(normalized) else current.add(normalized)
        save(context, current)
        return current
    }
}
