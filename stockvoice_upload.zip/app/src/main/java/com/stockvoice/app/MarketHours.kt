package com.stockvoice.app

import java.time.DayOfWeek
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.LocalTime

object MarketHours {
    private val zone = ZoneId.of("Asia/Kolkata")
    private val open = LocalTime.of(9, 15)
    private val close = LocalTime.of(15, 30)

    fun isOpen(now: ZonedDateTime = ZonedDateTime.now(zone)): Boolean {
        val weekday = now.dayOfWeek != DayOfWeek.SATURDAY && now.dayOfWeek != DayOfWeek.SUNDAY
        return weekday && !now.toLocalTime().isBefore(open) && now.toLocalTime().isBefore(close)
    }
}
