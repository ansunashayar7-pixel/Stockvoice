package com.stockvoice.app

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object MarketDataClient {
    data class Quote(val symbol: String, val name: String, val price: Double, val changePct: Double, val demo: Boolean = false, val asOf: String? = null)

    private fun baseUrl(context: Context): String = context.getSharedPreferences("stockvoice_prefs", Context.MODE_PRIVATE)
        .getString("backend_url", "http://10.0.2.2:8080")!!.trimEnd('/')

    fun fetchQuotes(context: Context, symbols: List<String>): List<Quote> {
        if (symbols.isEmpty()) return emptyList()
        val encoded = symbols.distinct().joinToString(",") { URLEncoder.encode(it, "UTF-8") }
        val url = URL("${baseUrl(context)}/quotes?symbols=$encoded")
        val c = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"; connectTimeout = 5000; readTimeout = 7000
            setRequestProperty("Accept", "application/json")
        }
        return try {
            if (c.responseCode !in 200..299) return emptyList()
            val body = c.inputStream.bufferedReader().use { it.readText() }
            val root = JSONObject(body); val arr = root.optJSONArray("quotes") ?: return emptyList()
            buildList {
                for (i in 0 until arr.length()) {
                    val q = arr.getJSONObject(i)
                    add(Quote(
                        q.getString("symbol").uppercase(), q.optString("name", q.getString("symbol")),
                        q.getDouble("price"), q.optDouble("changePct", 0.0),
                        q.optBoolean("demo", root.optBoolean("demo", false)), q.optString("asOf", null)
                    ))
                }
            }
        } finally { c.disconnect() }
    }
}
