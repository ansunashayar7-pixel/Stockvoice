package com.stockvoice.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import android.app.Activity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

private const val PREFS = "stockvoice_prefs"
private const val KEY_INTERVAL = "interval"
private const val KEY_SESSION = "session"
private const val KEY_LANGUAGE = "language"
private const val KEY_CHANGE = "announce_change"

private val symbols = listOf("RELIANCE", "TATAMOTORS", "INFY", "HDFCBANK", "TCS")
private val names = mapOf("RELIANCE" to "Reliance Industries", "TATAMOTORS" to "Tata Motors", "INFY" to "Infosys", "HDFCBANK" to "HDFC Bank", "TCS" to "TCS")

data class Stock(val name: String, val symbol: String, val price: Double, val changePct: Double, val demo: Boolean)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale("en", "IN") }
        setContent {
            var authenticated by remember { mutableStateOf(SecureTokenStore.token(this) != null) }
            if (authenticated) StockVoiceApp(::speak) else AuthGate { authenticated = true }
        }
    }
    private fun speak(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "stockvoice") }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}

@Composable
fun StockVoiceApp(onSpeak: (String) -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    val context = LocalContext.current
    var premium by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) { runCatching { MobileAds.initialize(context) {} } }
        premium = withContext(Dispatchers.IO) { runCatching { AuthClient.entitlements(context) }.getOrDefault(false) }
    }
    MaterialTheme(colorScheme = darkColorScheme(background = Color(0xFF06141D), surface = Color(0xFF102431), primary = Color(0xFF20E0B0), onPrimary = Color.Black)) {
        Scaffold(containerColor = Color(0xFF06141D), bottomBar = {
            NavigationBar(containerColor = Color(0xFF091C27)) {
                listOf("Home", "Watchlist", "Alerts", "Premium").forEachIndexed { i, label ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(listOf("⌂", "☆", "♧", "♛")[i], fontSize = 20.sp) }, label = { Text(label) })
                }
            }
        }) { pad ->
            when (tab) { 0 -> Home(pad, onSpeak, premium); 1 -> Watchlist(pad, onSpeak, premium); 2 -> Alerts(pad, onSpeak); 3 -> Premium(pad, premium) }
        }
    }
}

@Composable fun Header(title: String, sub: String? = null) {
    Column(Modifier.padding(horizontal = 20.dp, vertical = 18.dp)) { Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White); sub?.let { Text(it, color = Color.LightGray, fontSize = 14.sp) } }
}

@Composable
fun QuoteList(onSpeak: (String) -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var stocks by remember { mutableStateOf<List<Stock>>(emptyList()) }
    LaunchedEffect(Unit) {
        stocks = withContext(Dispatchers.IO) { runCatching { MarketDataClient.fetchQuotes(context, symbols) }.getOrDefault(emptyList()) }
    }
    if (stocks.isEmpty()) Text("Loading market data…", color = Color.Gray, modifier = modifier.padding(20.dp))
    else LazyColumn(modifier) { items(stocks, key = { it.symbol }) { StockRow(it, onSpeak) } }
}

@Composable
fun Home(pad: PaddingValues, onSpeak: (String) -> Unit, premium: Boolean) {
    Column(Modifier.padding(pad).fillMaxSize()) {
        Header("Good Morning 👋", "Stay informed without staring at the market.")
        Card(Modifier.padding(horizontal = 20.dp).fillMaxWidth(), colors = CardDefaults.cardColors(Color(0xFF123448))) {
            Column(Modifier.padding(18.dp)) { Text("🎙 Voice Alerts", color = Color(0xFF20E0B0), fontWeight = FontWeight.Bold); Text("StockVoice watches your selected stocks and speaks important updates.", color = Color.White) }
        }
        Spacer(Modifier.height(14.dp)); Text("Live feed", Modifier.padding(horizontal = 20.dp), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        QuoteList(onSpeak, Modifier.weight(1f).fillMaxWidth())
        if (!premium) {
            Spacer(Modifier.height(8.dp))
            TestBannerAd(Modifier.fillMaxWidth().wrapContentHeight())
        }
    }
}

@Composable
fun StockRow(s: Stock, onSpeak: (String) -> Unit) {
    Card(Modifier.padding(horizontal = 20.dp, vertical = 5.dp).fillMaxWidth(), colors = CardDefaults.cardColors(Color(0xFF102431))) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text(s.name, color = Color.White, fontWeight = FontWeight.SemiBold); Text(s.symbol + if (s.demo) " • DEMO" else "", color = Color.Gray, fontSize = 12.sp) }
            Column(horizontalAlignment = Alignment.End) { Text("₹${String.format(Locale.US, "%,.2f", s.price)}", color = Color.White); Text("${if (s.changePct >= 0) "+" else ""}${String.format(Locale.US, "%.2f", s.changePct)}%", color = if (s.changePct >= 0) Color(0xFF20E0B0) else Color(0xFFFF5570)) }
            Text(" 🔊", Modifier.clickable { onSpeak("${s.name} current price is ${String.format(Locale.US, "%.2f", s.price)} rupees. Movement ${String.format(Locale.US, "%.2f", s.changePct)} percent.") })
        }
    }
}

@Composable
fun Watchlist(pad: PaddingValues, onSpeak: (String) -> Unit, premium: Boolean) {
    val context = LocalContext.current
    var selected by remember { mutableStateOf(WatchlistRepository.load(context)) }
    val catalog = listOf(
        "RELIANCE" to "Reliance Industries",
        "TATAMOTORS" to "Tata Motors",
        "INFY" to "Infosys",
        "HDFCBANK" to "HDFC Bank",
        "TCS" to "TCS"
    )
    Column(Modifier.padding(pad).fillMaxSize()) {
        Header("My Watchlist", "Choose stocks for voice updates")
        Text("Stocks", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp))
        LazyColumn(Modifier.weight(1f).padding(top = 6.dp)) {
            items(catalog, key = { it.first }) { (symbol, name) ->
                val checked = symbol in selected
                Card(Modifier.padding(horizontal = 20.dp, vertical = 4.dp).fillMaxWidth(), colors = CardDefaults.cardColors(Color(0xFF102431))) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text(name, color = Color.White, fontWeight = FontWeight.SemiBold); Text(symbol, color = Color.Gray, fontSize = 12.sp) }
                        Checkbox(checked = checked, onCheckedChange = {
                            selected = WatchlistRepository.toggle(context, symbol)
                            kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch { runCatching { CloudSyncClient.push(context) } }
                        })
                    }
                }
            }
        }
        Text("Current prices", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
        QuoteList(onSpeak, Modifier.heightIn(max = 280.dp).fillMaxWidth())
        if (!premium) {
            Spacer(Modifier.height(8.dp))
            TestBannerAd(Modifier.fillMaxWidth().wrapContentHeight())
        }
    }
}

@Composable
fun TestBannerAd(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val adView = remember {
        AdView(context).apply {
            adUnitId = "ca-app-pub-3940256099942544/6300978111"
            setAdSize(AdSize.BANNER)
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
    }
    DisposableEffect(adView) {
        adView.loadAd(AdRequest.Builder().build())
        onDispose { adView.destroy() }
    }
    AndroidView(factory = { adView }, modifier = modifier)
}

@Composable
fun Alerts(pad: PaddingValues, onSpeak: (String) -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    var selectedInterval by remember { mutableIntStateOf(prefs.getInt(KEY_INTERVAL, 5)) }
    var active by remember { mutableStateOf(prefs.getBoolean(KEY_SESSION, false)) }
    var announceChange by remember { mutableStateOf(prefs.getBoolean(KEY_CHANGE, true)) }
    var language by remember { mutableStateOf(prefs.getString(KEY_LANGUAGE, "English") ?: "English") }
    var alerts by remember { mutableStateOf(AlertRepository.load(context)) }
    var selectedSymbol by remember { mutableStateOf("RELIANCE") }
    var ruleType by remember { mutableStateOf("ABOVE") }
    var valueText by remember { mutableStateOf("1450") }
    val intervals = listOf(5, 10, 15, 30, 60)

    LazyColumn(Modifier.padding(pad).fillMaxSize().padding(horizontal = 20.dp)) {
        item {
            Header("Voice Alerts", "Automatic updates + target price alerts")
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Color(0xFF102431))) {
                Column(Modifier.padding(16.dp)) {
                    Text("Voice interval", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) { intervals.forEach { m -> FilterChip(selected = selectedInterval == m, onClick = { selectedInterval = m; prefs.edit().putInt(KEY_INTERVAL, m).apply(); if (active) AlertScheduler.schedule(context, m.toLong()) }, label = { Text("${m}m") }) } }
                    Text(if (selectedInterval < 15) "5/10-minute mode uses exact alarms when permitted by Android. Battery-saving policies can still affect delivery." else "15–60 minute mode uses WorkManager and may run later than the selected interval.", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 12.dp)) { Column(Modifier.weight(1f)) { Text(if (active) "Voice session ON" else "Voice session OFF", color = Color.White, fontWeight = FontWeight.Bold); Text("Every $selectedInterval minutes", color = Color.Gray) }; Switch(checked = active, onCheckedChange = { active = it; prefs.edit().putBoolean(KEY_SESSION, it).apply(); if (it) AlertScheduler.schedule(context, selectedInterval.toLong()) else AlertScheduler.cancel(context) }) }
                    HorizontalDivider(Modifier.padding(vertical = 10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Announce % movement", color = Color.White); Text("Include daily percentage change", color = Color.Gray, fontSize = 12.sp) }; Switch(checked = announceChange, onCheckedChange = { announceChange = it; prefs.edit().putBoolean(KEY_CHANGE, it).apply() }) }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) { listOf("English", "Hindi").forEach { lang -> FilterChip(selected = language == lang, onClick = { language = lang; prefs.edit().putString(KEY_LANGUAGE, lang).apply() }, label = { Text(lang) }) } }
                }
            }
            Spacer(Modifier.height(14.dp))
            Button(onClick = { onSpeak("StockVoice test. Your voice alerts are working.") }, Modifier.fillMaxWidth()) { Text("🔊 Test Voice") }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = {
                if (selectedInterval < 15 && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                    val am = context.getSystemService(android.app.AlarmManager::class.java)
                    if (!am.canScheduleExactAlarms()) context.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply { data = Uri.parse("package:${context.packageName}") })
                }
                active = true; prefs.edit().putBoolean(KEY_SESSION, true).apply(); AlertScheduler.schedule(context, selectedInterval.toLong())
            }, Modifier.fillMaxWidth()) { Text("Start Voice Alerts") }
            Spacer(Modifier.height(8.dp)); OutlinedButton(onClick = { active = false; AlertScheduler.cancel(context) }, Modifier.fillMaxWidth()) { Text("Stop All Alerts") }
            Spacer(Modifier.height(18.dp)); Text("Create a price alert", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) { symbols.forEach { s -> FilterChip(selected = selectedSymbol == s, onClick = { selectedSymbol = s }, label = { Text(s) }) } }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) { listOf("ABOVE", "BELOW", "PCT_UP", "PCT_DOWN").forEach { t -> FilterChip(selected = ruleType == t, onClick = { ruleType = t }, label = { Text(if (t == "ABOVE") "Above" else if (t == "BELOW") "Below" else if (t == "PCT_UP") "% Up" else "% Down") }) } }
            OutlinedTextField(value = valueText, onValueChange = { valueText = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text(if (ruleType.startsWith("PCT")) "Percent" else "Target price (₹)") }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), singleLine = true)
            Button(onClick = { val value = valueText.toDoubleOrNull(); if (value != null && value > 0) { val a = PriceAlert(symbol = selectedSymbol, name = names[selectedSymbol] ?: selectedSymbol, type = ruleType, value = value); alerts = alerts + a; AlertRepository.save(context, alerts); runCatching { kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch { CloudSyncClient.push(context) } } } }, Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("Add Alert") }
            Spacer(Modifier.height(12.dp)); Text("Your target alerts", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        items(alerts, key = { it.id }) { a ->
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(Color(0xFF102431))) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(a.name, color = Color.White, fontWeight = FontWeight.SemiBold); Text(ruleLabel(a), color = Color.Gray, fontSize = 12.sp) }
                    TextButton(onClick = { alerts = alerts.filterNot { it.id == a.id }; AlertRepository.save(context, alerts); runCatching { kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch { CloudSyncClient.push(context) } } }) { Text("Delete") }
                }
            }
        }
        item { Spacer(Modifier.height(18.dp)); Text("Demo build note: the backend can simulate prices. Production will use a licensed market-data provider; no demo price is presented as live.", color = Color.Gray, fontSize = 12.sp); Spacer(Modifier.height(20.dp)) }
    }
}

private fun ruleLabel(a: PriceAlert): String = when (a.type) { "ABOVE" -> "Alert above ₹${a.value}"; "BELOW" -> "Alert below ₹${a.value}"; "PCT_UP" -> "Alert when up ${a.value}%"; else -> "Alert when down ${a.value}%" }

@Composable
fun Premium(pad: PaddingValues, serverPremium: Boolean) {
    val context = LocalContext.current
    val activity = context as? Activity
    val billing = remember { BillingManager(context) }
    var status by remember { mutableStateOf(if (serverPremium) "Premium active" else "Free plan") }
    DisposableEffect(Unit) {
        billing.connect { ok -> if (!ok) status = "Google Play Billing unavailable" }
        onDispose { billing.close() }
    }
    LaunchedEffect(serverPremium) { status = if (serverPremium) "Premium active" else "Free plan" }
    Column(Modifier.padding(pad).padding(20.dp)) {
        Header("Premium", "No ads + advanced alerts")
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Color(0xFF103A3A))) {
            Column(Modifier.padding(22.dp)) {
                Text("👑 StockVoice Premium", color = Color(0xFF20E0B0), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("₹149 / month", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text(status, color = if (serverPremium) Color(0xFF20E0B0) else Color.LightGray, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
                listOf("No ads", "Unlimited watchlist", "Price & % alerts", "5-minute voice mode", "Priority support").forEach { Text("✓ $it", color = Color.White, Modifier.padding(vertical = 4.dp)) }
                Spacer(Modifier.height(15.dp))
                if (!serverPremium) {
                    Button(onClick = { if (activity != null) billing.launchPremium(activity) { status = "Play Billing product not available" } }, Modifier.fillMaxWidth()) { Text("Get Premium") }
                    Text("Purchase is started through Google Play. Premium is unlocked only after server-side purchase verification.", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
                } else {
                    Text("Your account has a verified Premium entitlement.", color = Color.White)
                }
                Spacer(Modifier.height(14.dp))
                OutlinedButton(onClick = { SecureTokenStore.clear(context); context.startActivity(Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)) }, Modifier.fillMaxWidth()) { Text("Log out") }
            }
        }
    }
}
