# StockVoice v1.5

StockVoice is an Android voice-alert prototype for stock-price monitoring.

## v0.8 improvements
- Persistent watchlist (up to 50 symbols).
- 5/10 minute exact-alarm architecture and 15/30/60 minute WorkManager scheduling.
- Price-crossing alert de-duplication: an alert speaks on the crossing, not every subsequent poll while the condition remains true.
- Weekend/market-hours guard using Asia/Kolkata and the normal NSE equity session (09:15–15:30 IST). Exchange holidays are not yet included.
- Re-scheduling after device reboot/app update when the user had an active session.
- Backend provider adapter with validation and normalized quote shape.
- Demo feed remains explicitly simulated.
- Backend quote cache to reduce upstream calls.

## Important production work still required
1. Select a market-data provider and obtain written redistribution/display rights for a public commercial app.
2. Put provider credentials only on the backend.
3. Add an authenticated user API rather than exposing provider endpoints directly.
4. Add exchange holiday calendar and corporate-action handling.
5. Add proper Play Billing purchase + backend entitlement verification.
6. Add ads only in free tier and remove them for Premium.
7. Complete privacy policy, terms, financial-feature disclosures and Play Console declarations.
8. Run Gradle build and real-device tests; this workspace does not include the Android SDK, so APK compilation is not claimed here.

## Backend
```bash
cd backend
npm install
npm start
```

Demo mode is the default. For a licensed provider, set:
- `MARKET_DATA_PROVIDER=upstream`
- `MARKET_DATA_URL=https://provider.example/quotes?symbols={symbols}`
- `MARKET_DATA_TOKEN=...`

The exact provider URL/response mapping must be adapted to the licensed provider's API contract.

## v0.9 account & premium foundation
- Email/password registration and login.
- Passwords are salted scrypt hashes on the backend; never stored plaintext.
- Android auth token is encrypted with Android Keystore before local storage.
- `/auth/me` and `/me/entitlements` identify the account and server-owned premium state.
- Premium must be granted only by verified Google Play Billing backend processing in production; the Android client cannot self-grant premium.
- Production hardening still required: HTTPS-only, managed database, rate limiting, email verification, account deletion/export, encryption at rest, audit logging without secrets, and Google Play subscription verification/RTDN.

## v1.0 account sync + billing foundation
- Authenticated cloud sync endpoints: `GET /me/sync` and `PUT /me/sync` for watchlist and price-alert data.
- Android `CloudSyncClient` can pull/push the signed-in user's watchlist and alerts.
- Google Play Billing subscription client is wired to product ID `stockvoice_premium_monthly`.
- Billing callback deliberately does not self-grant Premium; production must send the Play purchase token to the backend for verification and entitlement management.
- Local token remains encrypted with Android Keystore.

## Production security checklist
- Use HTTPS only; never ship the development `http://10.0.2.2` backend URL.
- Replace JSON-file persistence with a managed database with encryption at rest and backups.
- Add rate limiting, email verification, password reset, account deletion/export, audit logging and abuse monitoring.
- Implement Google Play purchase-token verification and Real-time Developer Notifications before enabling Premium in production.


## v1.1 changes
- Watchlist screen now lets the user add/remove supported stocks and syncs changes to the account.
- Premium screen reads the server-owned entitlement and starts the Google Play subscription flow when configured.
- Added safer bearer-token signature length checking on the backend.
- Premium is still NOT self-granted by the Android app; production requires Google Play purchase-token verification + subscription lifecycle processing on the backend.
- This source project is not an APK; an Android SDK/Gradle build environment is required to compile it.

## v1.2 changes
- Exact-alarm scheduling is now preferred for **all 5/10/15/30/60-minute voice sessions**, so 15–60 minute sessions can also trigger the actual voice service when Android grants exact-alarm access.
- If exact-alarm access is unavailable, 15/30/60-minute sessions safely fall back to WorkManager; Android may delay those runs.
- Switching intervals now cancels the previous scheduling path before creating the new one, reducing duplicate sessions.
- This remains a prototype: exchange holidays, licensed live-data credentials, production subscription verification, ads/consent, and Play compliance are still pending.


## v1.3 changes
- Added Google Mobile Ads SDK for the free tier.
- Free users see a test banner on Home and Watchlist; verified Premium users do not see those banners.
- Beta build uses Google's official test App ID/ad unit IDs only; live AdMob IDs must be configured before production.
- Added a clear production note for consent/privacy requirements and ad configuration.
- Market-data architecture remains backend-only: no provider credentials are stored in the APK. TrueData currently advertises authorized NSE/BSE/MCX real-time APIs, but StockVoice still needs a commercial data agreement and the provider's exact API contract/credentials before enabling live production data.

## v1.3 build status
- This ZIP is source code, not an APK. The current workspace still has no Android SDK/Gradle installation, so no APK is claimed. Android's official tooling supports building APK/AAB in a CI/cloud build environment as well as Android Studio.

## v1.4 changes
- Added a GitHub Actions cloud-build workflow at `.github/workflows/android-debug.yml`.
- The workflow installs JDK 17 + Gradle 8.10.2 on a hosted runner and uploads the generated debug APK as a workflow artifact.
- Android version bumped to 1.4.0 / versionCode 13.
- This is the practical path for beta APK generation without a laptop: the source can be pushed to a GitHub repository and the workflow can build the APK in the cloud.
- Production Premium still requires server-side Google Play verification and subscription lifecycle handling. Google's current guidance requires purchase verification on a secure backend before granting subscription entitlement. citeturn0search0turn0search2


## v1.5 changes
- Cloud-build workflow is hardened for Android SDK 35: hosted runner now installs the Android SDK platform/build-tools before compiling.
- Android version bumped to 1.5.0 / versionCode 14.
- This keeps APK generation laptop-independent once the project is pushed to a GitHub repository.
- Live NSE/BSE data is intentionally NOT enabled with guessed credentials. A commercial app needs a provider agreement and the provider's approved API contract/redistribution rights. TrueData currently advertises authorized NSE/BSE/MCX real-time APIs, while its published terms say redistribution/public third-party use requires the applicable approvals/licensing. citeturn0search0turn0search1

## v1.5 build path
1. Put this project into a GitHub repository.
2. Open GitHub Actions and run **StockVoice Android Debug APK**.
3. The hosted runner installs Android SDK 35 and Gradle, builds the debug APK, and uploads it as an artifact.
4. Download the artifact on the phone and install the APK for beta testing (with Android's normal sideload permission if required).

The current chat environment cannot itself authenticate to a user's GitHub account or install an APK on the phone, so no fake APK is claimed.
